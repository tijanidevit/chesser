<title>Chesstar</title>
<meta charset="utf-8">

<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- <meta name="format-detection" content="telephone=no"> -->

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/animations.css">
<link rel="stylesheet" href="css/font-awesome5.css">
<link rel="stylesheet" href="css/icomoon.css">
<link rel="stylesheet" href="css/main.css" class="color-switcher-link">
<link rel="stylesheet" href="css/shop.css" class="color-switcher-link">
<script src="js/vendor/modernizr-2.6.2.min.js"></script>