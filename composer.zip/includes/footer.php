<footer class="page_footer footer-1 text-center text-sm-left  ds s-pt-60 s-pb-30 c-mb-30 s-bordertop">
	<div class="container-fluid">
		<div class="row justify-content-center align-items-center">

			<div class="col-xl-2 col-12 text-xl-left text-center  animate" data-animation="fadeInUp">
				<a href="index.html" class="logo">
					<img src="img/logo.png" alt="">
				</a>
			</div>

			<div class="col-xl-8 col-12 text-center animate" data-animation="fadeInUp">

				<p>&copy; Copyright <span class="copyright_year">2019</span> All Rights Reserved</p>
			</div>
			<div class="col-xl-2 col-12 text-center text-xl-right animate" data-animation="fadeInUp">
				<span class="social-icons">
					<a href="#" class="fab fab fa-facebook-f @@iconClass" title="facebook"></a>
					<a href="#" class="fab fa-telegram-plane @@iconClass" title="telegram"></a>
					<a href="#" class="fab fa-linkedin-in @@iconClass" title="linkedin"></a>
					<a href="#" class="fab fa-instagram @@iconClass" title="instagram"></a>
				</span>
			</div>

		</div>
	</div>
</footer>